
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vetocode',
  applicationName: 'aws-node-http-api-project',
  appUid: 'j5M7ZsHm75SnJ916rs',
  orgUid: '14b42b02-156f-414c-a3bb-3b49322b2b2b',
  deploymentUid: '21036a03-b634-4729-a168-f4c161093620',
  serviceName: 'aws-node-http-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-http-api-project-dev-getAnt', timeout: 6 };

try {
  const userHandler = require('./antHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getAnt, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}